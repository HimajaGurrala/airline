import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../services/booking.service';
import { Booking } from './booking';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  
 flight_id:number

 booking = new Booking( 0,"","","","",new Date(), new Date(),0,"");

  constructor(public bookingService: BookingService, private router: Router,private activatedRoute:ActivatedRoute) { }
  ngOnInit(): void {
   this.flight_id=this.activatedRoute.snapshot.params['flight_id'];
  }
  public newBooking(){
    /*this.bookingService.newBooking(this.booking).subscribe(
      (data:any)=>{
        this.booking=data;
        console.log("Booking Successfully!"+data);
        alert("Booked");
      }
    )*/
  }
}

