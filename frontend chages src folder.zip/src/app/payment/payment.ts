
export class Payment{
    paymentId:number;
    bookingId:number;
    ticketPrice:number;
    nameOnCard:string;
    cardNumber:number;
    expYear:string;
    cvv:number;
    paymentStatus:string;

 
    constructor(
 
         paymentId:number,
         bookingId:number,
         ticketPrice:number,
         nameOnCard:string,
         cardNumber:number,
         expYear:string,
         cvv:number,
         paymentStatus:string,
      
         )
{  
   this.paymentId=paymentId;
   this.bookingId;
   this.ticketPrice=ticketPrice;
   this.nameOnCard=nameOnCard;
   this.cardNumber=cardNumber;
   this.expYear=expYear;
   this.cvv=cvv;
   this.paymentStatus=paymentStatus;
  
 }}

 